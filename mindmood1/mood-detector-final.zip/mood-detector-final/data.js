// ===========================
// Mood Detection Dataset
// ===========================

const MOOD_DATA = {
    moods: {
        amused: {
            emoji: "😄",
            color: "#fbbf24",
            recommendation: "You're feeling amused! Keep enjoying this light-hearted moment. Share laughter with others and engage in activities that bring you joy. This is a perfect time for creative projects or spending time with loved ones."
        },
        angry: {
            emoji: "😠",
            color: "#ef4444",
            recommendation: "You're feeling angry. It's important to acknowledge this emotion. Try taking deep breaths, going for a walk, or engaging in physical activity to channel this energy. Consider talking to someone you trust about what's bothering you."
        },
        disgusted: {
            emoji: "🤢",
            color: "#8b5cf6",
            recommendation: "You're feeling disgusted. Take a step back from the situation that triggered this feeling. Engage in activities that refresh your mind and spirit. Sometimes a change of environment or perspective can help shift this emotion."
        },
        neutral: {
            emoji: "😐",
            color: "#9ca3af",
            recommendation: "You're feeling neutral. This is a balanced state perfect for reflection and planning. Use this time to assess your goals, organize your thoughts, or prepare for upcoming challenges. Consider what might bring more joy to your day."
        },
        sleepy: {
            emoji: "😴",
            color: "#60a5fa",
            recommendation: "You're feeling sleepy. Your body might need rest. Consider taking a nap, getting some fresh air, or engaging in a relaxing activity. Ensure you're getting enough quality sleep and maintaining a healthy sleep schedule."
        }
    },

    keywords: {
        amused: [
            "amused", "funny", "hilarious", "laugh", "laughing", "laughter", "joke", "comic",
            "entertaining", "fun", "playful", "silly", "witty", "humorous", "cheerful",
            "delighted", "tickled", "giddy", "giggly", "chuckling", "smiling", "happy",
            "joyful", "enjoying", "pleased", "content", "light-hearted", "carefree"
        ],
        angry: [
            "angry", "furious", "rage", "mad", "livid", "irritated", "annoyed", "frustrated",
            "upset", "outraged", "enraged", "seething", "fuming", "bitter", "resentful",
            "hostile", "aggressive", "cross", "irate", "indignant", "wrathful", "incensed",
            "provoked", "exasperated", "vexed", "infuriated", "antagonistic"
        ],
        disgusted: [
            "disgusted", "disgust", "repulsed", "revolted", "appalled", "sickened", "nauseated",
            "repugnant", "abhorrent", "loathsome", "vile", "gross", "yuck", "ew", "eww",
            "revolting", "offensive", "distasteful", "unpleasant", "repellent", "abominable",
            "detestable", "contemptible", "despicable", "foul", "putrid", "disgusting"
        ],
        neutral: [
            "neutral", "okay", "fine", "alright", "normal", "regular", "usual", "average",
            "meh", "so-so", "neither", "neither good nor bad", "mediocre", "ordinary",
            "standard", "typical", "unremarkable", "indifferent", "balanced", "stable",
            "steady", "consistent", "unchanged", "same", "moderate", "fair", "plain"
        ],
        sleepy: [
            "sleepy", "tired", "exhausted", "fatigued", "drowsy", "weary", "worn out",
            "drained", "lethargic", "sluggish", "groggy", "yawning", "dozing", "napping",
            "sleepless", "insomnia", "rest", "sleep", "nap", "bed", "tired out", "beat",
            "knackered", "wiped out", "zonked", "dead tired", "bushed", "pooped"
        ]
    },

    tips: {
        amused: [
            "Share your laughter with others",
            "Engage in activities you love",
            "Watch something funny",
            "Spend time with fun people",
            "Create something new",
            "Celebrate the moment"
        ],
        angry: [
            "Take deep breaths and pause",
            "Go for a walk or exercise",
            "Talk to someone you trust",
            "Journal your feelings",
            "Practice relaxation techniques",
            "Give yourself time to cool down"
        ],
        disgusted: [
            "Step away from the situation",
            "Refresh your environment",
            "Engage in pleasant activities",
            "Talk about your feelings",
            "Practice self-care",
            "Change your perspective"
        ],
        neutral: [
            "Reflect on your day",
            "Plan for the future",
            "Try something new",
            "Spend time in nature",
            "Connect with others",
            "Practice mindfulness"
        ],
        sleepy: [
            "Take a rest or nap",
            "Get some fresh air",
            "Stay hydrated",
            "Engage in light activity",
            "Improve sleep schedule",
            "Relax before bedtime"
        ]
    },

    affirmations: {
        amused: [
            "I deserve to feel joy and laughter",
            "My happiness is contagious",
            "I am grateful for moments of joy",
            "Laughter heals my soul",
            "I choose to find humor in life"
        ],
        angry: [
            "I can manage my anger with grace",
            "My anger is valid but temporary",
            "I choose to respond, not react",
            "I am in control of my emotions",
            "I will find peace"
        ],
        disgusted: [
            "I can move past this feeling",
            "I choose to focus on positive things",
            "This feeling will pass",
            "I am resilient and strong",
            "I deserve better experiences"
        ],
        neutral: [
            "I am balanced and grounded",
            "I am open to new experiences",
            "I am exactly where I need to be",
            "I am ready for whatever comes",
            "I am at peace with the present"
        ],
        sleepy: [
            "Rest is essential for my wellbeing",
            "I deserve quality sleep",
            "My body knows what it needs",
            "Sleep restores my energy",
            "I am taking care of myself"
        ]
    },

    activities: {
        amused: [
            "Watch a comedy or funny video",
            "Spend time with funny friends",
            "Play games or sports",
            "Create something fun",
            "Share jokes or memes",
            "Enjoy your favorite entertainment"
        ],
        angry: [
            "Go for a run or workout",
            "Practice deep breathing",
            "Take a cold shower",
            "Write about your feelings",
            "Listen to calming music",
            "Talk to a trusted friend"
        ],
        disgusted: [
            "Take a break from the trigger",
            "Engage in a favorite hobby",
            "Spend time in nature",
            "Practice gratitude",
            "Do something kind for yourself",
            "Change your environment"
        ],
        neutral: [
            "Meditate or practice yoga",
            "Read a book",
            "Plan your week",
            "Spend time outdoors",
            "Connect with loved ones",
            "Engage in creative pursuits"
        ],
        sleepy: [
            "Take a nap or rest",
            "Get some fresh air",
            "Stretch and move gently",
            "Drink water or herbal tea",
            "Prepare for quality sleep",
            "Relax in a comfortable space"
        ]
    }
};

// ===========================
// Sample Mood History Data
// ===========================

const SAMPLE_HISTORY = [
    {
        mood: "amused",
        confidence: 85,
        type: "text",
        timestamp: new Date(Date.now() - 1000 * 60 * 5),
        emoji: "😄"
    },
    {
        mood: "neutral",
        confidence: 78,
        type: "voice",
        timestamp: new Date(Date.now() - 1000 * 60 * 30),
        emoji: "😐"
    },
    {
        mood: "sleepy",
        confidence: 82,
        type: "text",
        timestamp: new Date(Date.now() - 1000 * 60 * 60),
        emoji: "😴"
    },
    {
        mood: "angry",
        confidence: 72,
        type: "voice",
        timestamp: new Date(Date.now() - 1000 * 60 * 120),
        emoji: "😠"
    },
    {
        mood: "amused",
        confidence: 88,
        type: "text",
        timestamp: new Date(Date.now() - 1000 * 60 * 180),
        emoji: "😄"
    }
];

// ===========================
// Mood Colors for Charts
// ===========================

const MOOD_COLORS = {
    amused: "#fbbf24",
    angry: "#ef4444",
    disgusted: "#8b5cf6",
    neutral: "#9ca3af",
    sleepy: "#60a5fa"
};

// ===========================
// Confidence Levels
// ===========================

const CONFIDENCE_LEVELS = {
    low: { min: 0, max: 40, label: "Low Confidence" },
    medium: { min: 40, max: 70, label: "Medium Confidence" },
    high: { min: 70, max: 100, label: "High Confidence" }
};
