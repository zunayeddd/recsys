// ===========================
// Global Variables
// ===========================

let uploadedFile = null;
let moodHistory = [];

// ===========================
// Page Navigation
// ===========================

function showPage(pageName) {
    // Hide all pages
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => page.classList.remove('active'));
    
    // Show selected page
    document.getElementById(pageName).classList.add('active');
    
    // Update nav links
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => link.classList.remove('active'));
    event.target.classList.add('active');
    
    // Update dashboard if navigating to it
    if (pageName === 'dashboard') {
        updateDashboard();
    }
}

// ===========================
// Tab Switching
// ===========================

function switchTab(tabName) {
    // Hide all tabs
    const tabs = document.querySelectorAll('.tab-content');
    tabs.forEach(tab => tab.classList.remove('active'));
    
    // Show selected tab
    document.getElementById(tabName + '-tab').classList.add('active');
    
    // Update tab buttons
    const tabBtns = document.querySelectorAll('.tab-btn');
    tabBtns.forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
}

// ===========================
// Text Input Handling
// ===========================

const textInput = document.getElementById('text-input');
const charCount = document.getElementById('char-count');

if (textInput) {
    textInput.addEventListener('input', function() {
        charCount.textContent = this.value.length;
        
        // Limit to 500 characters
        if (this.value.length > 500) {
            this.value = this.value.substring(0, 500);
            charCount.textContent = '500';
        }
    });
}

// ===========================
// Voice Upload System
// ===========================

const uploadArea = document.getElementById('upload-area');
const voiceInput = document.getElementById('voice-input');
const fileInfo = document.getElementById('file-info');
const analyzeVoiceBtn = document.getElementById('analyze-voice-btn');

// Click to upload
uploadArea.addEventListener('click', () => {
    voiceInput.click();
});

// File selected via input
voiceInput.addEventListener('change', handleFileSelect);

// Drag and drop
uploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadArea.style.borderColor = '#8b5cf6';
    uploadArea.style.backgroundColor = 'rgba(139, 92, 246, 0.1)';
});

uploadArea.addEventListener('dragleave', () => {
    uploadArea.style.borderColor = '#e2e8f0';
    uploadArea.style.backgroundColor = 'transparent';
});

uploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadArea.style.borderColor = '#e2e8f0';
    uploadArea.style.backgroundColor = 'transparent';
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
        voiceInput.files = files;
        handleFileSelect();
    }
});

function handleFileSelect() {
    const file = voiceInput.files[0];
    
    if (!file) return;
    
    // Check if file is audio
    if (!file.type.startsWith('audio/')) {
        alert('Please select an audio file');
        return;
    }
    
    // Check file size (max 50MB)
    if (file.size > 50 * 1024 * 1024) {
        alert('File size must be less than 50MB');
        return;
    }
    
    uploadedFile = file;
    
    // Display file info
    document.getElementById('file-name').textContent = file.name;
    document.getElementById('file-size').textContent = `Size: ${(file.size / 1024 / 1024).toFixed(2)} MB`;
    
    // Create audio preview
    const audioUrl = URL.createObjectURL(file);
    document.getElementById('audio-element').src = audioUrl;
    
    // Show file info and analyze button
    uploadArea.style.display = 'none';
    fileInfo.style.display = 'block';
    analyzeVoiceBtn.style.display = 'block';
}

function clearUpload() {
    uploadedFile = null;
    voiceInput.value = '';
    uploadArea.style.display = 'block';
    fileInfo.style.display = 'none';
    analyzeVoiceBtn.style.display = 'none';
    document.getElementById('audio-element').src = '';
}

// ===========================
// Mood Analysis
// ===========================

function analyzeMood(type) {
    let input = '';
    
    if (type === 'text') {
        input = document.getElementById('text-input').value.trim();
        if (!input) {
            alert('Please enter some text to analyze');
            return;
        }
    } else if (type === 'voice') {
        if (!uploadedFile) {
            alert('Please upload an audio file first');
            return;
        }
        input = uploadedFile.name; // Use filename as input for analysis
    }
    
    // Analyze mood
    const result = detectMood(input);
    
    // Display results
    displayResults(result);
    
    // Save to history
    const historyEntry = {
        mood: result.mood,
        confidence: result.confidence,
        type: type,
        timestamp: new Date(),
        emoji: result.emoji
    };
    moodHistory.push(historyEntry);
    
    // Save to localStorage
    localStorage.setItem('moodHistory', JSON.stringify(moodHistory));
}

function detectMood(input) {
    // Get mood keywords from data
    const moodKeywords = MOOD_DATA.keywords;
    const moodScores = {
        amused: 0,
        angry: 0,
        disgusted: 0,
        neutral: 0,
        sleepy: 0
    };
    
    const lowerInput = input.toLowerCase();
    
    // Count keyword matches
    Object.entries(moodKeywords).forEach(([mood, keywords]) => {
        keywords.forEach(keyword => {
            const regex = new RegExp(`\\b${keyword}\\b`, 'gi');
            const matches = lowerInput.match(regex);
            if (matches) {
                moodScores[mood] += matches.length;
            }
        });
    });
    
    // Find mood with highest score
    let detectedMood = 'neutral';
    let maxScore = 0;
    
    Object.entries(moodScores).forEach(([mood, score]) => {
        if (score > maxScore) {
            maxScore = score;
            detectedMood = mood;
        }
    });
    
    // Calculate confidence
    const inputLength = input.split(/\s+/).length;
    let confidence = Math.min(100, 50 + (maxScore * 5) + Math.min(inputLength * 2, 20));
    
    if (maxScore === 0) {
        detectedMood = 'neutral';
        confidence = 60;
    }
    
    confidence = Math.round(confidence);
    
    // Get mood data
    const moodInfo = MOOD_DATA.moods[detectedMood];
    
    return {
        mood: detectedMood,
        confidence: confidence,
        emoji: moodInfo.emoji,
        recommendation: moodInfo.recommendation,
        color: moodInfo.color
    };
}

function displayResults(result) {
    // Show results section
    document.getElementById('results').style.display = 'block';
    
    // Update result display
    document.getElementById('result-emoji').textContent = result.emoji;
    document.getElementById('result-mood').textContent = result.mood;
    document.getElementById('confidence-value').textContent = result.confidence;
    document.getElementById('recommendation-text').textContent = result.recommendation;
    
    // Update confidence bar
    const confidenceFill = document.getElementById('confidence-fill');
    confidenceFill.style.width = result.confidence + '%';
    
    // Scroll to results
    document.getElementById('results').scrollIntoView({ behavior: 'smooth' });
}

function resetDetector() {
    // Clear inputs
    document.getElementById('text-input').value = '';
    charCount.textContent = '0';
    clearUpload();
    
    // Hide results
    document.getElementById('results').style.display = 'none';
}

// ===========================
// Dashboard
// ===========================

function updateDashboard() {
    // Load history from localStorage
    const savedHistory = localStorage.getItem('moodHistory');
    if (savedHistory) {
        moodHistory = JSON.parse(savedHistory);
    }
    
    // Update stats
    updateStats();
    
    // Update mood distribution
    updateMoodDistribution();
    
    // Update history list
    updateHistoryList();
}

function updateStats() {
    const totalDetections = moodHistory.length;
    document.getElementById('total-detections').textContent = totalDetections;
    
    // Calculate average confidence
    if (totalDetections > 0) {
        const avgConfidence = Math.round(
            moodHistory.reduce((sum, item) => sum + item.confidence, 0) / totalDetections
        );
        document.getElementById('avg-confidence').textContent = avgConfidence + '%';
    } else {
        document.getElementById('avg-confidence').textContent = '0%';
    }
    
    // Find most frequent mood
    if (totalDetections > 0) {
        const moodCounts = {};
        moodHistory.forEach(item => {
            moodCounts[item.mood] = (moodCounts[item.mood] || 0) + 1;
        });
        
        const mostFrequent = Object.entries(moodCounts).sort(([, a], [, b]) => b - a)[0];
        const frequentMood = mostFrequent ? mostFrequent[0] : 'N/A';
        const emoji = MOOD_DATA.moods[frequentMood]?.emoji || '';
        document.getElementById('frequent-mood').textContent = `${emoji} ${frequentMood}`;
    } else {
        document.getElementById('frequent-mood').textContent = '-';
    }
}

function updateMoodDistribution() {
    const distributionContainer = document.getElementById('mood-distribution');
    
    if (moodHistory.length === 0) {
        distributionContainer.innerHTML = '<p style="color: #94a3b8;">No mood data yet. Start detecting moods!</p>';
        return;
    }
    
    // Count moods
    const moodCounts = {};
    moodHistory.forEach(item => {
        moodCounts[item.mood] = (moodCounts[item.mood] || 0) + 1;
    });
    
    // Create bars
    let html = '';
    Object.entries(moodCounts).forEach(([mood, count]) => {
        const percentage = (count / moodHistory.length) * 100;
        const moodInfo = MOOD_DATA.moods[mood];
        
        html += `
            <div class="mood-bar">
                <div class="mood-label">${moodInfo.emoji} ${mood}</div>
                <div class="mood-bar-fill" style="background: linear-gradient(90deg, ${moodInfo.color}, #ec4899);">
                    <div class="mood-bar-text">${count}</div>
                </div>
            </div>
        `;
    });
    
    distributionContainer.innerHTML = html;
}

function updateHistoryList() {
    const historyContainer = document.getElementById('history-list');
    
    if (moodHistory.length === 0) {
        historyContainer.innerHTML = '<p style="color: #94a3b8;">No mood history yet.</p>';
        return;
    }
    
    // Show last 10 entries
    const recentHistory = moodHistory.slice(-10).reverse();
    let html = '';
    
    recentHistory.forEach((item, index) => {
        const time = new Date(item.timestamp).toLocaleTimeString();
        const date = new Date(item.timestamp).toLocaleDateString();
        
        html += `
            <div class="history-item">
                <div style="display: flex; align-items: center; flex: 1;">
                    <span class="history-item-emoji">${item.emoji}</span>
                    <div class="history-item-info">
                        <div class="history-item-mood">${item.mood}</div>
                        <div class="history-item-time">${date} at ${time}</div>
                    </div>
                </div>
                <div class="history-item-confidence">${item.confidence}%</div>
            </div>
        `;
    });
    
    historyContainer.innerHTML = html;
}

// ===========================
// Initialize
// ===========================

document.addEventListener('DOMContentLoaded', function() {
    // Load history from localStorage
    const savedHistory = localStorage.getItem('moodHistory');
    if (savedHistory) {
        moodHistory = JSON.parse(savedHistory);
    }
    
    // Set up event listeners for nav links
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const pageName = this.getAttribute('href').substring(1);
            showPage(pageName);
            
            // Update active state
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
        });
    });
});
